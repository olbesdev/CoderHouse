# Desafío obligatorio : Motores de plantillas

#### Backend CoderHouse 32070 Handlebars

Para la ejecucion:

```
nodemon server.js
```

### Jonathan Olbes 2022.
