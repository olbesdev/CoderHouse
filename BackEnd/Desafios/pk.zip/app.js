const express = require('express')
const cookieParser = require('cookie-parser')
require('dotenv').config()
const logger = require('morgan')
const { resolve4 } = require('dns')


const app = express()

app.use(logger('dev'))
app.use(cookieParser())
app.use(express.json())
app.use(express.urlencoded({extended: true}))



app.get('/health', async(req, res) => {
    res.status(200).json({
        success: true,
        message: 'Health UP'
    })
})

//Ruta para Cookies
app.get('/cookies', async(req,res) => {
    const {cookies} = req;
    res.status(200).json(cookies)
})

//Ruta creación de cookies

app.post('/cookies', async(req, res) => {
    const {name, value} = req.body
    if(!name || !value){
        res.status(400).json({
            success: false,
            message: "Error con nombre o vlor de cookie"
        })
    }
    res.cookie(name, value)
    res.status(200).json({
        success: true,
        message: "Cookie Guardada"
    })
})

module.exports = app